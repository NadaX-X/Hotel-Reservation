
public class Singlsroom extends Room {
public Singlsroom(int exstrabeds) {
        super(exstrabeds);
    }

    @Override
    public double payablee() {
        return ((getExstrabeds() * 50) + getPrice()) * tax
                + (getExstrabeds() * 50) + getPrice();
    }

    public Singlsroom() {

    }

    @Override
    public String Services() {
        return "The service available is:[free breakfast]";
    }
        @Override
    public void display() {
        super.display();
        Services();
        

    }

    @Override
    public String toString() {
        return super.toString() + "\n" + Services() + "\n Total price is: " + payablee();
    }

    
}
