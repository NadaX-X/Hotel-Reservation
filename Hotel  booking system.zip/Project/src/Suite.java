
public class Suite extends Units{
public Suite(int exstrabeds) {
        super(1500, exstrabeds);

    }

    public Suite() {
        super(1500, 0);
    }

    @Override
    public double payablee() {

        return ((getExstrabeds() * 100) + getPrice()) * tax
                + (getExstrabeds() * 100) + getPrice();

    }

    @Override
    public String Services() {
        return " The services available are:[free breakfast] and [free lunch]";
    }
    @Override
    public void display() {
        super.display();
        Services();
    }

    @Override
    public String toString() {
        return super.toString() + "\n Number of Exstra beds: " + getExstrabeds()
                + " \n " + Services() + " \n Total price is " + payablee();
    }

    
}
