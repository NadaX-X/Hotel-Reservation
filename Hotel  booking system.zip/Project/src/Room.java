
public abstract class Room extends Units{
public Room(int exstrabeds) {
        super(1000,exstrabeds);
    }    
    public Room() {
    super(1000, 0);
    }
    @Override
    public String toString() {
    return super.toString() +"\n Number of Exstra beds:"+ getExstrabeds();
    }

}    

