
public abstract class Units implements payable{
private int exstrabeds;
    private final int price;

    public Units(int price, int exstrabeds) {
        this.price = price;
        setExstrabeds(exstrabeds);
    }

    public int getExstrabeds() {
        return exstrabeds;
    }

    public void setExstrabeds(int exstrabeds) {
        if (exstrabeds >= 1) {
            this.exstrabeds = exstrabeds;
        }
    }

    public int getPrice() {
        return price;
    }

    public abstract String Services();

    @Override
    public String toString() {
        return "\n Unit Type:" + getClass().getSimpleName()
                + "\n Price:" +getPrice();
    }

    public void display() {
        System.out.println("\n Unit Type:" + getClass().getSimpleName());
        System.out.println(" Price:" + getPrice());

    }

   
}
