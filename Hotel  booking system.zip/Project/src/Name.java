
public class Name {
private String FirstName;
    private String SecendName;
    private String LastName;

    public Name(String FirstName, String SecendName, String LastName) {
        this.FirstName = FirstName;
        this.SecendName = SecendName;
        this.LastName = LastName;
    }

    public Name() {
        this ("","","");
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getSecendName() {
        return SecendName;
    }

    public void setSecendName(String SecendName) {
        this.SecendName = SecendName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    @Override
    public String toString() {
        return "\nThe name is: " + FirstName + " " + SecendName + " " + LastName;
    }
    public void display (){
        System.out.println("The name is: " + FirstName + " " + SecendName + " " + LastName);
        
    }
    
}
