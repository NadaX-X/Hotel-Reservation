
 import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TextFileRead {
//read = scanner 
// write = formatter

private Scanner input;
// open
public void openFile(String file) {
        try {

            input = new Scanner(new File(file));
        } catch (FileNotFoundException ex) {
            System.err.println("Error opening or creating file.");
        }
    }
// read 
    public void read() {
        try {
            while (input.hasNextLine()) {
                System.out.println(input.nextLine());
            }
        } catch (NoSuchElementException ex) {
            System.err.println("File improperly formed.");
        } catch (IllegalStateException ex) {
            System.err.println("Error reading from file.");
        }
    }
// close
    public void closeFile() {
        if (input != null) {
            input.close();
        }
    }
}
