
import java.util.*;
public class Main {
public static void main(String[] args) {   
Scanner x = new Scanner(System.in);
        ArrayList<payable> a = new ArrayList<payable>();
        // creating an object
        Units u = new Doubleroom();
        Units u2 = new Suite();
        Units u1 = new Singlsroom();
        //compsition array
        Booking b = new Booking(new Guest(1111,new Name("F1 name","S1 Name","L1 name"),"Email",19), new Date(1,1,2001),u1);
        Booking b1 = new Booking(new Guest(2222,new Name("F2 name","S2 Name","L2 name"),"Email",20), new Date(2,2,2002),u1);
        payable[]ar=new payable[2];
        ar[0]=b;
        ar[1]=b1;
        a.add(b);
        a.add(u);
        a.add(u2);
        TextFileWrite w = new TextFileWrite();
        w.openFile("Units.txt");
        for (payable j : a)
        w.write(j);
        w.closeFile();
        TextFileRead R = new TextFileRead();
        // creating an object
        R.openFile("Units.txt");  
        R.read();
        R.closeFile();

//----------------------------------------------------------
       
        try {
            int num1;
            do {
                Scanner r = new Scanner(System.in);
                System.out.println("****************************");                       
                System.out.println("Welcom to the Star " +"Hotel \n"
                        + "1- Show all Units \n"
                        + "2- Show Suite \n"
                        + "3- Rooms \n"
                        + "4- show Details units\n"
                        + "5- New Booking \n"
                        + "6- Exit ");
                System.out.println("****************************");
                num1 = r.nextInt();
                switch (num1) {

                    case 1:
                        poly(u1);
                        poly(u);
                        poly(u2);
                        break;
                    case 2:
                        poly(u2);
                        break;
                    case 3:
                        System.out.print("****Rooms****");
                        poly(u1);
                        poly(u);
                        break;
                    case 4:
                      
                        showu();
                       
                        break;

                    case 5:
                        book();
                        showu();
                        System.out.println(" Your booking is done successfully, Thank you for choosing stars hotel! ");

                        break;

                    default:
                        System.out.println("Invalid Choice ");
                        break;
                }
            } while (num1 != 6);

        } catch (InputMismatchException ex) {
            System.out.println("Invalid input");
        }

    }

    public static void poly(Units y) {
        y.display();

    }

    public static void showu() {
       
        Scanner f = new Scanner(System.in);
        int un = 0;
        try {

            System.out.println(" 1- Single room\n 2- Double room \n 3- Suite \n" + " 4- Exit"+"\nenter the num for what you want?");
            un = f.nextInt();
            switch (un) {
                case 1:
                    System.out.println("Enter number of beds? ");
                    int num = f.nextInt();
                    Units ss = new Singlsroom(num);
                    System.out.println(ss);
                    break;
                case 2:
                    System.out.println("Enter number of beds? ");
                    num = f.nextInt();
                    Units rr = new Doubleroom(num);
                    System.out.println(rr);

                    break;
                case 3:
                    System.out.println("Enter number of beds? ");
                    num = f.nextInt();
                    Units s = new Suite(num);
                    System.out.println(s);
                    break;
                case 4:
                    break;

                default:
                    System.out.println("invalid Choice ");
            }

        } catch (InputMismatchException x) {
            System.out.println("Invalid input");

        }
    
    }

    public static void book() {
        Scanner x = new Scanner(System.in);

        try {
            System.out.print("Enter the day: ");
            int day =x.nextInt();
            System.out.print("Enter the month: ");
            int mounth =x.nextInt();
            System.out.print("Enter the year: ");
            int year =x.nextInt();
            Date d = new Date(day, mounth, year);
            System.out.println("--- Enter your information --- ");
            System.out.print("Enter your ID: ");
            int id = x.nextInt();
            System.out.print("FirstName:");
            String FirstName = x.next();

            System.out.print("SecendName:");
            String SecondName = x.next();

            System.out.print("LastName:");
            String LastName = x.next();

            Name n = new Name(FirstName, SecondName, LastName);
            System.out.print("Enter your Email: ");
            String Email = x.next();
            System.out.print("Enter your Age: ");
            int Age = x.nextInt();
            Guest g = new Guest(id, n, Email, Age);
            Booking b = new Booking(g, d);//
        } catch (InputMismatchException ex) {
            System.err.println("Invalid Input");

        }
    }
}