
public class Doubleroom extends Room{
public Doubleroom(int exstrabeds) {
        super(exstrabeds);
    }
    @Override
    public double payablee() {
        return ((getExstrabeds() * 70) + getPrice()) * tax
                + (getExstrabeds() * 70) + getPrice();
    }
    public Doubleroom() {
    }
    @Override
    public String Services() {
        return " The service available is:[free breakfast]";
    }

   @Override
    public void display() {
        super.display();
        Services();
    }
    @Override
    public String toString() {
        return super.toString() +"\n" + Services() + "\n Total price is:" + payablee();
    }
}
