
public class Date {
private int day;
    private int month;
    private int year;

    public Date(int day, int mounth, int year) {
       setDay(day) ;
       setMonth(mounth);
       setYear(year);
    }

    public Date() {
        this (0,0,0);
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public void setDay(int day) {
        if (day > 0 && day <= 30) {
            this.day = day;
        }
    }

    public void setMonth(int month) {
        if (month > 0 && month <= 12) {
            this.month = month;

        }
    }

    public void setYear(int year) {
        if (year > 0) {
            this.year = year;

        }
    }

    @Override
    public String toString() {
        return "\n Date is:" + day + "/" + month + "/" + year;

    }
    public void display(){
        System.out.println("\n Date is:" + getDay() + "/" + getMonth() + "/" + getYear());
    }

    
}
