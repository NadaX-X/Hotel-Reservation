
public final class Booking implements payable{
private static int numofbookings = 0; /////////
    private Guest guest; // done 
    private Units units; // ليست ارري لانها بتحجز غرفة واحد فقط يعني ما يمديه يحجز مرة ثانية
    private Date date; // date of booking
   public  Booking(Guest guest, Date date) {
    this.guest = guest;
    this.date = date;
    numofbookings++; //numofbookings+1
    }  
    public Booking(Guest guest, Date date,Units units) {
        this(guest,date);
        this.units = units;
        
    }

    
    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public static int getNumofbookings() {
        return numofbookings;
    }

    public static void setNumofbookings(int numofbookings) {
        Booking.numofbookings = numofbookings;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Units getUnits() {
        return units;
    }

    public void setUnits(Units units) {
        this.units = units;
    }
     @Override
    public  double payablee(){
        return 0.0;
    }
    public void display() {
        System.out.println("\n information of guest");
        guest.display();
        date.display();
        System.out.println("----------------------------");
        units.display();
        System.out.println("");
    }

    @Override
    public String toString() {
        return "\n *  information of guest  *"
                + guest.toString()
                + date.toString()
                + "\n------------------"
                + "\n" + units.toString()
                + "\n";
    }

   
    
}
