
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;
public class TextFileWrite {
private Formatter output; 
//open
    //method
    public void openFile(String name) {
        try {
            
            output = new Formatter(name);
        } // end try
        catch (SecurityException ex) {
            System.err.println("You do not have write access to this file.");
              
        } 
        catch (FileNotFoundException ex) {
            System.err.println("Error opening or creating file.");
           
    } 
    } 
    // write
    public void write (payable P) { // متغ يرعادي
        try {
            output.format("%s",P.toString());
            
            output.format("\n");
        } 
        catch (FormatterClosedException ex) {
            System.err.println("Error writing to file"); 
        }
    } 

   // close !!كيف اقفل ملف فاضي
    public void closeFile() {
        if (output != null) {
            output.close();
        }
    } 


}

    

