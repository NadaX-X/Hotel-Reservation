
public class Guest {
private final int id;
    private Name name;
    private String Email;
    private int age;

    public Guest(int id, Name name, String Email, int age) {
        this.id = id;
        this.name = name;
        this.Email = Email;
        setAge(age);
    }

    public Guest() {
        this(0, new Name("", "", ""), "", 0);
    }

    public int getId() {
        return id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
    return name.toString() + "\n id is:" + id + "\n age is:" + age + "\n" + "Eamail: " + getEmail();
    }

 

  public void display() {
     System.out.println("\n Name: ");
        name.display(); // void can not be in void M !
        System.out.println("\n ID: " + getId());
        System.out.println("\n Eamail: " + getEmail());
        System.out.println("\n age: " + getAge());

    }
    
}
